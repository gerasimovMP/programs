import java.util.HashMap;
import java.util.Map;

public class Var_table {


    String name;
    double value;

    Var_table(String name, double value){
        this.name = name;
        this.value = value;
    }


}
