//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

public class Token {
    String type;
    String token;

    Token(){}

    Token(String Type, String Token) {
        this.type = Type;
        this.token = Token;
    }
}
